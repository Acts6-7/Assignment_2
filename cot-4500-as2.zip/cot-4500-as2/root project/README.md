Numerical Methods Implementation

Overview

This project implements various numerical methods for interpolation and approximation, including:  
\- Neville's Method  
\- Newton's Forward Interpolation  
\- Hermite Polynomial Approximation  
\- Cubic Spline Interpolation

The project includes both the implementation of these numerical methods and their corresponding test cases.

Requirements

The following Python libraries are required to run the code:

pip install numpy scipy

Code Implementation

The main implementation is located in \`assignment\_2.py\` and includes the following functions:

1\. Neville's Method

\`\`\`python  
def neville(x\_vals, y\_vals, x):  
\`\`\`  
This function computes an interpolated value using Neville’s method.

2\. Newton's Forward Interpolation

\`\`\`python  
def newton\_forward\_diff\_table(x\_vals, y\_vals):  
def newton\_forward\_interpolation(x\_vals, diff\_table, x):  
\`\`\`  
These functions generate the forward difference table and compute interpolated values using Newton's method.

3\. Hermite Polynomial Approximation

\`\`\`python  
def hermite\_interpolation(x\_vals, y\_vals, y\_derivs):  
\`\`\`  
This function computes the Hermite polynomial interpolation.

4\. Cubic Spline Interpolation

\`\`\`python  
def cubic\_spline\_matrices(x\_vals, y\_vals):  
\`\`\`  
This function constructs the coefficient matrix and vector for cubic spline interpolation.

Test Suite

Unit tests are provided in \`test\_assignment\_2.py\`, using Python’s \`unittest\` framework. The test cases validate the correctness of each interpolation method.

Running Tests

To run the tests, execute:

\`\`\`sh  
python \-m unittest discover src/test  
\`\`\`

Output Example

After running the script, expected outputs include interpolated values and computed matrices, such as:

\`\`\`  
Neville's method result for f(3.7): 1.554  
Newton's forward method result for f(7.3): 24.47  
Hermite polynomial approximation matrix:  
\[\[ 1.67500000e+00  0.00000000e+00 ... \]\]  
Cubic spline vector x:  
\[-0.05405405  0.21621622\]  
\`\`\`

Author

Stephen Creary