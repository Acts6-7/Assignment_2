import sys
import os
import unittest
import numpy as np
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from src.main.assignment_2 import (
    neville,
    newton_forward_diff_table,
    newton_forward_interpolation,
    hermite_interpolation,
    cubic_spline_matrices
)

class TestNumericalMethods(unittest.TestCase):

    # 1. Neville's Method
    def test_neville(self):
        x_vals = np.array([3.6, 3.8, 3.9])
        y_vals = np.array([1.675, 1.436, 1.318])
        x_interp = 3.7
        expected_result = 1.554  
        self.assertAlmostEqual(neville(x_vals, y_vals, x_interp), expected_result, places=2)

    # 2. Newton's Forward Interpolation
    def test_newton_forward(self):
        x_vals = np.array([7.2, 7.4, 7.5, 7.6])
        y_vals = np.array([23.5492, 25.3913, 26.8224, 27.4589])
        diff_table = newton_forward_diff_table(x_vals, y_vals)
        x_interp = 7.3
        expected_result = 24.470  
        self.assertAlmostEqual(newton_forward_interpolation(x_vals, diff_table, x_interp), expected_result, delta=0.03)

    # 3. Hermite Polynomial Approximation
    def test_hermite(self):
        x_vals = np.array([3.6, 3.8, 3.9])
        y_vals = np.array([1.675, 1.436, 1.318])
        y_derivs = np.array([-1.195, -1.188, -1.182])
        hermite_matrix = hermite_interpolation(x_vals, y_vals, y_derivs)
        self.assertIsInstance(hermite_matrix, np.ndarray)

    # 4. Cubic Spline Interpolation
    def test_cubic_spline(self):
        x_vals = np.array([2, 5, 8, 10])
        y_vals = np.array([3, 5, 7, 9])
        A, b = cubic_spline_matrices(x_vals, y_vals)
        self.assertEqual(A.shape[0], A.shape[1])
        self.assertEqual(A.shape[0], len(b))
        self.assertIsInstance(A, np.ndarray)
        self.assertIsInstance(b, np.ndarray)
    
    # 5. Test for Cubic Spline Interpolation
    def test_cubic_spline_solution(self):
        x_vals = np.array([2, 5, 8, 10])
        y_vals = np.array([3, 5, 7, 9])
        A, b = cubic_spline_matrices(x_vals, y_vals)
        x_spline = np.linalg.solve(A, b)
        self.assertIsInstance(x_spline, np.ndarray)
        self.assertEqual(len(x_spline), len(b))

if __name__ == '__main__':
    unittest.main()
