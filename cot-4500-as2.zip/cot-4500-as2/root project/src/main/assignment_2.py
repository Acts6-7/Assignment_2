import numpy as np
import scipy.linalg as la
import scipy.interpolate as spi

# 1. Neville's Method

def neville(x_vals, y_vals, x):
    n = len(x_vals)
    Q = np.zeros((n, n))
    Q[:, 0] = y_vals
    
    for j in range(1, n):
        for i in range(n - j):
            Q[i, j] = ((x - x_vals[i + j]) * Q[i, j - 1] - (x - x_vals[i]) * Q[i + 1, j - 1]) / (x_vals[i] - x_vals[i + j])
    
    return Q[0, n - 1]

x_vals = np.array([3.6, 3.8, 3.9])
y_vals = np.array([1.675, 1.436, 1.318])
x_interp = 3.7
result_neville = neville(x_vals, y_vals, x_interp)
print("Neville's method result for f(3.7):", result_neville)

# 2. Newton's Forward Interpolation

def newton_forward_diff_table(x_vals, y_vals):
    n = len(x_vals)
    diff_table = np.zeros((n, n))
    diff_table[:, 0] = y_vals
    
    for j in range(1, n):
        for i in range(n - j):
            diff_table[i, j] = diff_table[i + 1, j - 1] - diff_table[i, j - 1]
    
    return diff_table

x_vals_newton = np.array([7.2, 7.4, 7.5, 7.6])
y_vals_newton = np.array([23.5492, 25.3913, 26.8224, 27.4589])
diff_table = newton_forward_diff_table(x_vals_newton, y_vals_newton)
print("Newton's forward difference table:\n", diff_table)

# 3. Using Newton's interpolation to approximate f(7.3)

def newton_forward_interpolation(x_vals, diff_table, x):
    n = len(x_vals)
    h = x_vals[1] - x_vals[0]
    p = (x - x_vals[0]) / h
    result = diff_table[0, 0]
    term = 1
    
    for i in range(1, n):
        term *= (p - (i - 1)) / i
        result += term * diff_table[0, i]
    
    return result

x_interp_newton = 7.3
result_newton = newton_forward_interpolation(x_vals_newton, diff_table, x_interp_newton)
print("Newton's forward method result for f(7.3):", result_newton)

# 4. Hermite Polynomial Approximation

def hermite_interpolation(x_vals, y_vals, y_derivs):
    n = len(x_vals)
    z = np.zeros(2 * n)
    Q = np.zeros((2 * n, 2 * n))
    
    for i in range(n):
        z[2 * i] = z[2 * i + 1] = x_vals[i]
        Q[2 * i, 0] = Q[2 * i + 1, 0] = y_vals[i]
        Q[2 * i + 1, 1] = y_derivs[i]
        
        if i != 0:
            Q[2 * i, 1] = (Q[2 * i, 0] - Q[2 * i - 1, 0]) / (z[2 * i] - z[2 * i - 1])
    
    for j in range(2, 2 * n):
        for i in range(2 * n - j):
            Q[i, j] = (Q[i + 1, j - 1] - Q[i, j - 1]) / (z[i + j] - z[i])
    
    return Q

x_vals_hermite = np.array([3.6, 3.8, 3.9])
y_vals_hermite = np.array([1.675, 1.436, 1.318])
y_derivs_hermite = np.array([-1.195, -1.188, -1.182])
hermite_matrix = hermite_interpolation(x_vals_hermite, y_vals_hermite, y_derivs_hermite)
print("Hermite polynomial approximation matrix:\n", hermite_matrix)

# 5. Cubic Spline Interpolation

def cubic_spline_matrices(x_vals, y_vals):
    n = len(x_vals) - 1
    h = np.diff(x_vals)
    A = np.zeros((n - 1, n - 1))
    b = np.zeros(n - 1)
    
    for i in range(1, n):
        A[i - 1, i - 1] = 2 * (h[i - 1] + h[i])
        if i - 1 > 0:
            A[i - 1, i - 2] = h[i - 1]
        if i < n - 1:
            A[i - 1, i] = h[i]
        
        b[i - 1] = 6 * ((y_vals[i + 1] - y_vals[i]) / h[i] - (y_vals[i] - y_vals[i - 1]) / h[i - 1])
    
    return A, b

x_vals_spline = np.array([2, 5, 8, 10])
y_vals_spline = np.array([3, 5, 7, 9])
A_spline, b_spline = cubic_spline_matrices(x_vals_spline, y_vals_spline)
x_spline = np.linalg.solve(A_spline, b_spline)
print("Cubic spline matrix A:\n", A_spline)
print("Cubic spline vector b:\n", b_spline)
print("Cubic spline vector x:\n", x_spline)

